# Sweet Crumbs Bakery - Part 2

## Part 2: Designing the Visuals

### CSS Styling
- Added an external stylesheet: `Css/style.css`
- Linked the stylesheet to all HTML pages.
- Added consistent fonts, colours, spacing and layout.
- Used Flexbox for the navigation.
- Used CSS Grid for the main content layouts.

### Responsive Design
- Added desktop, tablet and mobile breakpoints.
- Used `rem` and `%` values for responsive sizing and spacing.
- Product and location sections change to smaller layouts on smaller screens.
- Added responsive images using `picture`, `srcset` and `sizes`.

### User Experience
- Kept the navigation consistent on every page.
- Added readable text sizes and clear spacing.
- Added labels to form fields.
- Added alternative text to images.
- Maps and images adjust to smaller screens.

### Changelog
#### Part 2
- Added external CSS styling.
- Added responsive desktop, tablet and mobile layouts.
- Added responsive image versions.
- Updated image paths to match the `Images` folder.
- Updated the HTML structure to work with the new CSS.
- Added accessibility improvements to images, navigation and forms.

## Screenshot Evidence

The `Evidence` folder is for the required desktop, tablet and mobile screenshots. Open `index.html` at each screen size and save screenshots there before submission.

## References

Mozilla Developer Network (MDN). (2026). CSS. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS (Accessed: 17 September 2026).

Mozilla Developer Network (MDN). (2026). CSS media queries. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries (Accessed: 17 September 2026).

Mozilla Developer Network (MDN). (2026). The picture element. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/picture (Accessed: 17 September 2026).
